from django.shortcuts import render
from .models import Journal

# Create your views here.

def journal_view(request):
	journals = Journal.objects.all()
	return render(request, 'journal.html', {'journals': journals})