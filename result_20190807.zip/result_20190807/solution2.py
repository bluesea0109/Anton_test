import re
import requests
from bs4 import BeautifulSoup

def get_word_frequency(url):
	res = requests.get(url)
	html_page = res.content
	soup = BeautifulSoup(html_page, 'html.parser')
	content = soup.find_all(text=True)

	texts = ''
	blacklist = [
		'[document]',
		'noscript',
		'header',
		'html',
		'meta',
		'head', 
		'input',
		'script',
	]

	for seg in content:
		if seg.parent.name not in blacklist:
			texts += '{} '.format(seg)

	texts = re.sub('[^A-Za-z\s]+', '', texts)

	output = {}

	for word in texts.split(' '):
		if word in output:
			output[word] += 1
		else:
			output[word] = 1

	return output

url = 'https://www.troyhunt.com/the-773-million-record-collection-1-data-reach/'
frequency = get_word_frequency(url)

print(frequency)
