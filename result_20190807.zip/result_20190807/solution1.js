const f = (firstName) => new Promise(function(resolve, reject) {
  setTimeout(() => {
  	if ( !firstName ) {
  		reject(new Error('firstName is required'))	
  	} else {
  		const fullName = `${firstName} Smith`
  		resolve( fullName )	
  	}
  }, 2000);
})

f('Andrew')
	.then((fullname) => {
		console.log(fullname)
	})
	.then((err) => {
		console.error(err)
	})

f(null)
	.then((fullname) => {
		console.log(fullname)
	})
	.then((err) => {
		console.error(err)
	})