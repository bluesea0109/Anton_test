function calculate(arr, max, pos, flag, count, match) {
    if (pos === arr.length) {
        if (count === match) {
            let final = [];
            arr.map((value, index) => {
                if (index != 0 || flag[index] !== 2)
                    final.push(flag[index] === 2 ? ' + ' : ' - ');
                final.push(value);
            })
            console.log(`${match} =  ${final.join('')}`)
            return true;
        }
        return false;
    }
    
    let maxVal = count + max[pos + 1] + arr[pos], minVal = count - max[pos + 1] + arr[pos]
    
    if (maxVal >= match && minVal <= match) {
        
        flag[pos] = 2;
        
        if (calculate(arr, max, pos + 1, flag, count + arr[pos], match))
            return true;
    }
    maxVal = count + max[pos + 1] - arr[pos], minVal = count - max[pos + 1] - arr[pos]

    flag[pos] = 1;
    
    if (calculate(arr, max, pos + 1, flag, count - arr[pos], match))
        return true;
    
    flag[pos] = 0;
    
    return false;
}

function f(arr, match) {
    let max = [...arr, 0], flg = Array().fill(0)

    max.reduceRight((tot, value, index) => {
        return (max[index] = tot + Math.abs(value))
    })

    if (calculate(arr, max, 0, flg, 0, match) === false)
        console.log('None')
}

f([1, 2, 3, 4, 5], 9)
f([2, 5, 60, -5, 3], 69)
f([2, 5, 10], 50)